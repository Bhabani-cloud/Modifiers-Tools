bl_info = {
    "name": "Bhabani Modifier Tools",
    "author": "Bhabani Tudu",
    "version": (1, 0),
    "blender": (4, 4, 0),
    "location": "View3D > Sidebar > Modifier Tools",
    "description": "Toggle a modifier's visibility, sync shading, and toggle Emulate 3 Button Mouse",
    "category": "Object",
}

import bpy

addon_keymaps = []

# Operator to toggle modifier and shading
class OBJECT_OT_toggle_modifier_and_shading(bpy.types.Operator):
    bl_idname = "object.toggle_modifier_shading"
    bl_label = "Toggle Modifier + Shading"
    bl_options = {'REGISTER', 'UNDO'}

    modifier_name: bpy.props.StringProperty(
        name="Modifier Name",
        default="Subdivision"
    )

    def execute(self, context):
        for obj in context.selected_objects:
            mod = obj.modifiers.get(self.modifier_name)
            if mod:
                mod.show_viewport = not mod.show_viewport
                context.view_layer.objects.active = obj
                bpy.ops.object.shade_smooth() if mod.show_viewport else bpy.ops.object.shade_flat()
        return {'FINISHED'}

# Operator to toggle Emulate 3 Button Mouse setting
class PREFERENCES_OT_toggle_emulate_3_button_mouse(bpy.types.Operator):
    bl_idname = "preferences.toggle_emulate_3_button_mouse"
    bl_label = "Toggle Emulate 3 Button Mouse"

    def execute(self, context):
        prefs = bpy.context.preferences.inputs
        if hasattr(prefs, "use_mouse_emulate_3_button"):
            prefs.use_mouse_emulate_3_button = not prefs.use_mouse_emulate_3_button
            self.report({'INFO'}, f"Emulate 3 Button Mouse: {prefs.use_mouse_emulate_3_button}")
            return {'FINISHED'}
        else:
            self.report({'ERROR'}, "Property not found.")
            return {'CANCELLED'}

# Unified Panel in Modifier Tools tab
class VIEW3D_PT_modifier_shading_panel(bpy.types.Panel):
    bl_label = "Modifier Tools"
    bl_idname = "VIEW3D_PT_modifier_shading_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Modifier Tools'

    def draw(self, context):
        layout = self.layout
        layout.operator("preferences.toggle_emulate_3_button_mouse", icon="MOUSE_LMB")
        layout.operator("object.toggle_modifier_shading")

# Class list for registration
classes = [
    OBJECT_OT_toggle_modifier_and_shading,
    PREFERENCES_OT_toggle_emulate_3_button_mouse,
    VIEW3D_PT_modifier_shading_panel,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    # Add shortcut: Ctrl + Shift + 1
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='Window', space_type='EMPTY')
        kmi = km.keymap_items.new(
            PREFERENCES_OT_toggle_emulate_3_button_mouse.bl_idname,
            type='ONE', value='PRESS', ctrl=True, shift=True
        )
        addon_keymaps.append((km, kmi))

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

if __name__ == "__main__":
    register()
